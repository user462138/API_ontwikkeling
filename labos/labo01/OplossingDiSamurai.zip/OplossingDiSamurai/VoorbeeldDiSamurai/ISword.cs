﻿namespace OplossingDiOefeningSamurai
{
    internal interface ISword
    {
    }
}