﻿namespace OplossingDiOefeningSamurai
{
    public interface ITrigger
    {
        void Pull();
    }
}
