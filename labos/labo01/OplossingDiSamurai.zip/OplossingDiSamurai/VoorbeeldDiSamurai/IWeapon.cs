﻿namespace OplossingDiOefeningSamurai
{
    public interface IWeapon
    {
        void Hit(string target);
    }
}
