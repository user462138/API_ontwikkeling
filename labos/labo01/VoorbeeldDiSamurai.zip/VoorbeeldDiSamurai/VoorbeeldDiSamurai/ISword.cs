﻿namespace VoorbeeldDiSamurai
{
    internal interface ISword
    {
    }
}