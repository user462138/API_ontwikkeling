﻿namespace VoorbeeldDiSamurai
{
    public interface IWeapon
    {
        void Hit(string target);
    }
}
